﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Inventory_System.SourceCode
{
    public class ComboHelper
    {
        public static void FillUserTypes(ComboBox cmb)
        {
            DataTable dtUserType = new DataTable();
                dtUserType.Columns.Add("UserTypeID");
                dtUserType.Columns.Add("UserType");
                dtUserType.Rows.Add("0", "---Select---");

            try
            {
                DataTable dt = DatabaseAccess.Retrieve("select UserTypeID, UserType from UserTypesTable");
                if (dt != null)
                {
                    if (dt.Rows.Count > 0)
                    {
                        foreach (DataRow usertype in dt.Rows)
                        {
                            dtUserType.Rows.Add(usertype["UserTypeID"], usertype["UserType"]);
                        }
                    }
                }
                cmb.DataSource = dtUserType;
                cmb.ValueMember = "UserTypeID";
                cmb.DisplayMember = "UserType";
            }
            catch
            {
                cmb.DataSource = dtUserType;
            }
            
        }

        public static void FillCategories(ComboBox cmb)
        {
            DataTable dtCategory = new DataTable();
            dtCategory.Columns.Add("CategoryID");
            dtCategory.Columns.Add("CategoryName");
            dtCategory.Rows.Add("0", "---Select---");

            try
            {
                DataTable dt = DatabaseAccess.Retrieve("select CategoryID, CategoryName from CategoryTable");
                if (dt != null)
                {
                    if (dt.Rows.Count > 0)
                    {
                        foreach (DataRow usertype in dt.Rows)
                        {
                            dtCategory.Rows.Add(usertype["CategoryID"], usertype["CategoryName"]);
                        }
                    }
                }
                cmb.DataSource = dtCategory;
                cmb.ValueMember = "CategoryID";
                cmb.DisplayMember = "CategoryName";
            }
            catch
            {
                cmb.DataSource = dtCategory;
            }
        }

        public static void FillVendors(ComboBox cmb)
        {
            DataTable dtVendor = new DataTable();
            dtVendor.Columns.Add("VendorID");
            dtVendor.Columns.Add("VendorName");
            dtVendor.Rows.Add("0", "---Select---");

            try
            {
                DataTable dt = DatabaseAccess.Retrieve("select VendorID, VendorName from VendorTable");
                if (dt != null)
                {
                    if (dt.Rows.Count > 0)
                    {
                        foreach (DataRow vendor in dt.Rows)
                        {
                            dtVendor.Rows.Add(vendor["VendorID"], vendor["VendorName"]);
                        }
                    }
                }
                cmb.DataSource = dtVendor;
                cmb.ValueMember = "VendorID";
                cmb.DisplayMember = "VendorName";
            }
            catch
            {
                cmb.DataSource = dtVendor;
            }
        }

        public static void FillSites(ComboBox cmb)
        {
            DataTable dtSite = new DataTable();
            dtSite.Columns.Add("SiteID");
            dtSite.Columns.Add("SiteName");
            dtSite.Rows.Add("0", "---Select---");

            try
            {
                DataTable dt = DatabaseAccess.Retrieve("select SiteID, SiteName from SiteTable");
                if (dt != null)
                {
                    if (dt.Rows.Count > 0)
                    {
                        foreach (DataRow site in dt.Rows)
                        {
                            dtSite.Rows.Add(site["SiteID"], site["SiteName"]);
                        }
                    }
                }
                cmb.DataSource = dtSite;
                cmb.ValueMember = "SiteID";
                cmb.DisplayMember = "SiteName";
            }
            catch
            {
                cmb.DataSource = dtSite;
            }
        }

        public static void FillTransporters(ComboBox cmb)
        {
            DataTable dtTransporter = new DataTable();
            dtTransporter.Columns.Add("TransporterID");
            dtTransporter.Columns.Add("TransporterName");
            dtTransporter.Rows.Add("0", "---Select---");

            try
            {
                DataTable dt = DatabaseAccess.Retrieve("select TransporterID, TransporterName from TransporterTable");
                if (dt != null)
                {
                    if (dt.Rows.Count > 0)
                    {
                        foreach (DataRow transporter in dt.Rows)
                        {
                            dtTransporter.Rows.Add(transporter["TransporterID"], transporter["TransporterName"]);
                        }
                    }
                }
                cmb.DataSource = dtTransporter;
                cmb.ValueMember = "TransporterID";
                cmb.DisplayMember = "TransporterName";
            }
            catch
            {
                cmb.DataSource = dtTransporter;
            }
        }
    }
}
