﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Inventory_System.Forms.StockForms
{
    public partial class receiveInventory : Form
    {
        public receiveInventory()
        {
            InitializeComponent();
        }

        public void FillGrid(string searchvalue)
        {
            string query = string.Empty;
            DataTable dt = new DataTable();
            if (string.IsNullOrEmpty(searchvalue) && string.IsNullOrWhiteSpace(searchvalue))
            {
                query = "select * from v_Purchase where Status = 'pending'";

            }
            else
            {
                query = "select * from v_Purchase where Status = 'pending' AND Ref# like '%" + searchvalue + "%'";
            }
            dt = DatabaseAccess.Retrieve(query);
            if (dt != null)
            {
                if (dt.Rows.Count > 0)
                {
                    dgvPurchaseOrdersList.DataSource = dt;
                    dgvPurchaseOrdersList.Columns[0].Width = 50;
                }
                else
                {
                    dgvPurchaseOrdersList.DataSource = null;
                }
            }
            else
            {
                dgvPurchaseOrdersList.DataSource = null;
            }
        }

        private void receiveInventory_Load(object sender, EventArgs e)
        {
            FillGrid("");
        }

        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            FillGrid(txtSearch.Text.Trim());
        }

        private void receiveToolStripMenuItem_Click(object sender, EventArgs e)
        {
            PurchaseOrder frm = new PurchaseOrder(this);
            frm.ShowDialog();
        }
    }
}
