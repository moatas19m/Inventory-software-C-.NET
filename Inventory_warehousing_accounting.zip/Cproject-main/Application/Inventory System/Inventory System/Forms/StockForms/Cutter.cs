﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Inventory_System.Forms.StockForms
{
    public partial class Cutter : Form
    {
        private Warehouse frm1;


        public Cutter(Warehouse frm)
        {
            InitializeComponent();
            frm1 = frm;
        }

        private void Cutter_Load(object sender, EventArgs e)
        {
            Warehouse frm = (Warehouse)Application.OpenForms["Warehouse"];
            int row = frm.dgvInventoryList.CurrentRow.Index;
            txtCoilID.Text = Convert.ToString(frm.dgvInventoryList[0, row].Value);
            txtThickness.Text = Convert.ToString(frm.dgvInventoryList[5, row].Value);
            txtWidth.Text = Convert.ToString(frm.dgvInventoryList[6, row].Value);
            txtTotalWeight.Text = Convert.ToString(frm.dgvInventoryList[14, row].Value);
            txtOrigin.Text = Convert.ToString(frm.dgvInventoryList[8, row].Value);
        }

        private void btnSend_Click(object sender, EventArgs e)
        {
            Warehouse frm = (Warehouse)Application.OpenForms["Warehouse"];
            int row = frm.dgvInventoryList.CurrentRow.Index;
            int totalweight = Convert.ToInt32(frm.dgvInventoryList[14, row].Value);

            ep.Clear();

            if (txtOrigin.Text.Trim().Length == 0)
            {
                ep.SetError(txtOrigin, "Please enter cutter location!");
                txtOrigin.Focus();
                return;
            }

            if (txtRefno.Text.Trim().Length == 0)
            {
                ep.SetError(txtRefno, "Please enter reference no.!");
                txtRefno.Focus();
                return;
            }

            if (txtQuantity.Text.Trim().Length == 0)
            {
                ep.SetError(txtQuantity, "Please enter quantity!");
                txtQuantity.Focus();
                return;
            }

            if (txtDimension.Text.Trim().Length == 0)
            {
                ep.SetError(txtDimension, "Please enter dimension!");
                txtDimension.Focus();
                return;
            }

            if (txtBilledBy.Text.Trim().Length == 0)
            {
                ep.SetError(txtBilledBy, "Please enter name!");
                txtBilledBy.Focus();
                return;
            }

            if (int.Parse(txtCalcWeight.Text.Trim()) == 0)
            {
                ep.SetError(txtCalcWeight, "Please enter cutting weight!");
                txtCalcWeight.Focus();
                return;
            }

            if (int.Parse(txtCalcWeight.Text.Trim()) > totalweight)
            {
                ep.SetError(txtCalcWeight, "Cutting weight is greater than total weight!");
                txtCalcWeight.Focus();
                return;
            }

            string insertquery = string.Format("insert into CuttingOrdersTable(ref_no, CoilID, date, thickness, width, dimension, origin, quantity, calculated_weight,billed_by) values('{0}', '{1}', '{2}', '{3}', '{4}', '{5}', '{6}', '{7}', '{8}', '{9}')", txtRefno.Text.Trim(), txtCoilID.Text.Trim(), dtpCuttingDate.Value.ToString("yyyy/MM/dd"), txtThickness.Text.Trim(), txtWidth.Text.Trim(), txtDimension.Text.Trim(), txtOrigin.Text.Trim(), txtQuantity.Text.Trim(), txtCalcWeight.Text.Trim(), txtBilledBy.Text.Trim());

            bool result = DatabaseAccess.Insert(insertquery);

            string updatequery = string.Format("update PurchaseTable set CurrentWeight = '{0}' where Coil_ID = '{1}'", txtTotalWeight.Text.Trim(), txtCoilID.Text.Trim());

            bool result2 = DatabaseAccess.Update(updatequery);


            if (result && result2)
            {
                MessageBox.Show("cutting order sent!");
                frm.FillGrid("");
                this.Close();
            }
            else
            {
                MessageBox.Show("error");
            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            dtpCuttingDate.Value = DateTime.Today;
            txtCalcWeight.Clear();
            txtBilledBy.Clear();
            txtQuantity.Clear();
            txtDimension.Clear();
            txtRefno.Clear();
        }

        private void btnAddVendor_Click(object sender, EventArgs e)
        {
            //TextBox txtdimension = new TextBox();
            //txtdimension.Name = "txtDimension1";
            //txtdimension.Size = new System.Drawing.Size(48, 22);
            //txtdimension.Location = new Point(122, 190);
            //this.Controls.Add(txtdimension);

            //TextBox txtquantity = new TextBox();
            //txtquantity.Name = "txtQuantity1";
            //txtquantity.Size = new System.Drawing.Size(74, 22);
            //txtquantity.Location = new Point(219, 190);
            //this.Controls.Add(txtquantity);
        }

        private void txtCalcWeight_TextChanged(object sender, EventArgs e)
        {
            Warehouse frm = (Warehouse)Application.OpenForms["Warehouse"];
            int row = frm.dgvInventoryList.CurrentRow.Index;
            int totalweight = Convert.ToInt32(frm.dgvInventoryList[14, row].Value);

            if (string.IsNullOrEmpty(txtCalcWeight.Text))
            {
                txtCalcWeight.Text = "0";
            }

            if (!string.IsNullOrEmpty(txtCalcWeight.Text) && !string.IsNullOrEmpty(txtTotalWeight.Text) && !System.Text.RegularExpressions.Regex.IsMatch(txtCalcWeight.Text, "[^0-9]"))
            {
                int TotalWeight = 0;
                TotalWeight = totalweight - int.Parse(txtCalcWeight.Text);
                txtTotalWeight.Text = TotalWeight.ToString();
            }
            else
            {
                ep.SetError(txtCalcWeight, "Error!");
                txtCalcWeight.Focus();
                return;
            }
        }
    }
}
