﻿using Inventory_System.SourceCode;
using iTextSharp.text;
using iTextSharp.text.html.simpleparser;
using iTextSharp.text.pdf;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Inventory_System.Forms.StockForms
{
    public partial class Products : Form
    {
        public Products()
        {
            InitializeComponent();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            ep.Clear();

            if (txtRefNo.Text.Trim().Length == 0)
            {
                ep.SetError(txtRefNo, "Please enter reference number!");
                txtRefNo.Focus();
                return;
            }

            if (txtCoilID.Text.Trim().Length == 0)
            {
                ep.SetError(txtCoilID, "Please enter coil id!");
                txtCoilID.Focus();
                return;
            }

            if (cmbSelectVendor.SelectedIndex == 0)
            {
                ep.SetError(cmbSelectVendor, "Please enter vendor nname!");
                cmbSelectVendor.Focus();
                return;
            }

            if (cmbSelectPayment.SelectedIndex == 1)
            {
                if (txtDays.Text.Trim().Length == 0)
                {
                    ep.SetError(txtDays, "Please enter number of days!");
                    txtDays.Focus();
                    return;
                }
            }

            if (txtGauge.Text.Trim().Length == 0)
            {
                ep.SetError(txtGauge, "Please enter product name!");
                txtGauge.Focus();
                return;
            }

            if (txtThickness.Text.Trim().Length == 0)
            {
                ep.SetError(txtThickness, "Please enter thickness!");
                txtThickness.Focus();
                return;
            }

            if (txtWidth.Text.Trim().Length == 0)
            {
                ep.SetError(txtWidth, "Please enter width!");
                txtWidth.Focus();
                return;
            }

            if (txtLocation.Text.Trim().Length == 0)
            {
                ep.SetError(txtLocation, "Please enter location!");
                txtLocation.Focus();
                return;
            }

            if (int.Parse(txtUnitPrice.Text.Trim()) == 0)
            {
                ep.SetError(txtUnitPrice, "Please enter unit price!");
                txtUnitPrice.Focus();
                return;
            }

            if (txtOrigin.Text.Trim().Length == 0)
            {
                ep.SetError(txtOrigin, "Please enter origin!");
                txtOrigin.Focus();
                return;
            }

            string checkquery = string.Format("select * from PurchaseTable where RefNo = '{0}' and Coil_ID = '{1}'", txtRefNo.Text.Trim(), txtCoilID.Text.Trim());

            DataTable dt = DatabaseAccess.Retrieve(checkquery);
            if (dt != null)
            {
                if (dt.Rows.Count > 0)
                {
                    ep.SetError(txtRefNo, "Already exists!");
                    txtRefNo.Focus();
                    return;
                }
            }
            
            if (txtDays.Enabled == true && dtpDueDate.Enabled == true)
            {
                string insertquery = string.Format("insert into PurchaseTable(Coil_ID,User_ID, RefNo, Date, Gauge, Thickness, Width, UnitPrice, Origin ,Payment, Vendor_ID, DeliveryFrom, Days, DueDate) values('{0}', '{1}', '{2}', '{3}', '{4}', '{5}', '{6}', '{7}', '{8}', '{9}', '{10}','{11}', '{12}', '{13}')", txtCoilID.Text.Trim(), CurrentUser.UserID, txtRefNo.Text.Trim(), dtpDate.Value.ToString("yyyy/MM/dd"), txtGauge.Text.Trim(), txtThickness.Text.Trim(), txtWidth.Text.Trim(), txtUnitPrice.Text.Trim(), txtOrigin.Text.Trim(), cmbSelectPayment.SelectedItem, cmbSelectVendor.SelectedValue, txtLocation.Text.Trim(), txtDays.Text.Trim(), dtpDueDate.Value.ToString("yyyy/MM/dd"));
                bool result = DatabaseAccess.Insert(insertquery);

                if (result)
                {
                    MessageBox.Show("Purchase added!");
                    FormClear();
                    FillGrid("");
                }
                else
                {
                    MessageBox.Show("Error");
                }
            }
            else
            {
                string insertquery = string.Format("insert into PurchaseTable(Coil_ID, User_ID, RefNo, Date, Gauge, Thickness, Width, UnitPrice, Origin ,Payment, Vendor_ID, DeliveryFrom, Days, DueDate) values('{0}', '{1}', '{2}', '{3}', '{4}', '{5}', '{6}', '{7}', '{8}', '{9}', '{10}','{11}', '{12}', '{13}')", txtCoilID.Text.Trim(), CurrentUser.UserID, txtRefNo.Text.Trim(), dtpDate.Value.ToString("yyyy/MM/dd"), txtGauge.Text.Trim(), txtThickness.Text.Trim(), txtWidth.Text.Trim(), txtUnitPrice.Text.Trim(), txtOrigin.Text.Trim(), cmbSelectPayment.SelectedItem, cmbSelectVendor.SelectedValue, txtLocation.Text.Trim(), '0', dtpDate.Value.ToString("yyyy/MM/dd"));
                bool result = DatabaseAccess.Insert(insertquery);

                if (result)
                {
                    MessageBox.Show("Purchase added!");
                    FormClear();
                    FillGrid("");
                }
                else
                {
                    MessageBox.Show("Error");
                }
            }

        }

        public void FillGrid(string searchvalue)
        {
            string query = string.Empty;
            DataTable dt = new DataTable();
            if (string.IsNullOrEmpty(searchvalue) && string.IsNullOrWhiteSpace(searchvalue))
            {
                query = "select * from v_Purchase";

            }
            else
            {
                query = "select * from v_Purchase where Ref# like '%" + searchvalue + "%'";
            }
            dt = DatabaseAccess.Retrieve(query); 
            if (dt != null)
            {
                if (dt.Rows.Count > 0)
                {
                    dgvPurchaseList.DataSource = dt;
                    dgvPurchaseList.Columns[0].Width = 50;
                }
                else
                {
                    dgvPurchaseList.DataSource = null;
                }
            }
            else
            {
                dgvPurchaseList.DataSource = null;
            }
        }

        private void FormClear()
        {
            txtGauge.Clear();
            txtThickness.Clear();
            txtCoilID.Clear();
            txtWidth.Clear();
            txtUnitPrice.Clear();
            dtpDate.Value = DateTime.Now;
            dtpDueDate.Value = DateTime.Now;
            txtOrigin.Clear();
            txtDays.Clear();
            cmbSelectVendor.SelectedIndex = 0;
            cmbSelectPayment.SelectedIndex = 0;
            txtRefNo.Clear();
        }

        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            FillGrid(txtSearch.Text.Trim());
        }

        private void Products_Load(object sender, EventArgs e)
        {
            FillGrid("");
            ComboHelper.FillVendors(cmbSelectVendor);
            cmbSelectPayment.SelectedIndex = 0;
        }

        private void deleteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (dgvPurchaseList != null)
            {
                if (dgvPurchaseList.Rows.Count > 0)
                {
                    if (dgvPurchaseList.SelectedRows.Count == 1)
                    {
                        if (MessageBox.Show("Are you sure you want to delete?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                        {
                            string deletequery = "delete from PurchaseTable where ID = '"+dgvPurchaseList.CurrentRow.Cells[0].Value+"'";

                            bool result = DatabaseAccess.Delete(deletequery);

                            if (result)
                            {
                                MessageBox.Show("Deleted successfully");
                                FillGrid("");
                            }
                        }
                    }
                    else
                    {
                        MessageBox.Show("Please select a record!");
                    }
                }
                else
                {
                    MessageBox.Show("List is empty!");
                }
            }
        }

        private void editToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ep.Clear();
            if (dgvPurchaseList != null)
            {
                if (dgvPurchaseList.Rows.Count > 0)
                {
                    if (dgvPurchaseList.SelectedRows.Count == 1)
                    {
                        txtRefNo.Text = Convert.ToString(dgvPurchaseList.CurrentRow.Cells[3].Value);

                        txtCoilID.Text = Convert.ToString(dgvPurchaseList.CurrentRow.Cells[2].Value);

                        cmbSelectVendor.SelectedIndex = cmbSelectVendor.FindStringExact( Convert.ToString(dgvPurchaseList.CurrentRow.Cells[4].Value));

                        var OnlyDate = Convert.ToString(dgvPurchaseList.CurrentRow.Cells[5].Value).Split(' ');
                        var CurrDate = OnlyDate[0].Split('/');
                        dtpDate.Value = new DateTime(int.Parse(CurrDate[2]), int.Parse(CurrDate[1]), int.Parse(CurrDate[0]));

                        txtGauge.Text = Convert.ToString(dgvPurchaseList.CurrentRow.Cells[6].Value);

                        txtThickness.Text = Convert.ToString(dgvPurchaseList.CurrentRow.Cells[7].Value);

                        txtWidth.Text = Convert.ToString(dgvPurchaseList.CurrentRow.Cells[8].Value);

                        txtUnitPrice.Text = Convert.ToString(dgvPurchaseList.CurrentRow.Cells[9].Value);

                        txtLocation.Text = Convert.ToString(dgvPurchaseList.CurrentRow.Cells[10].Value);

                        txtOrigin.Text = Convert.ToString(dgvPurchaseList.CurrentRow.Cells[11].Value);

                        cmbSelectPayment.SelectedIndex = cmbSelectPayment.FindStringExact(Convert.ToString(dgvPurchaseList.CurrentRow.Cells[12].Value));

                        txtDays.Text = Convert.ToString(dgvPurchaseList.CurrentRow.Cells[13].Value);

                        var OnlyDate1 = Convert.ToString(dgvPurchaseList.CurrentRow.Cells[14].Value).Split(' ');
                        var CurrDate1 = OnlyDate1[0].Split('/');
                        dtpDueDate.Value = new DateTime(int.Parse(CurrDate1[2]), int.Parse(CurrDate1[1]), int.Parse(CurrDate1[0]));

                        EnableControls();
                    }
                    else
                    {
                        MessageBox.Show("Please select a record!");
                    }
                }
                else
                {
                    MessageBox.Show("List is empty!");
                }
            }
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            ep.Clear();
            if (txtRefNo.Text.Trim().Length == 0)
            {
                ep.SetError(txtRefNo, "Please enter reference number!");
                txtRefNo.Focus();
                return;
            }

            if (txtCoilID.Text.Trim().Length == 0)
            {
                ep.SetError(txtCoilID, "Please enter coil id!");
                txtCoilID.Focus();
                return;
            }

            if (cmbSelectVendor.SelectedIndex == 0)
            {
                ep.SetError(cmbSelectVendor, "Please enter vendor name!");
                cmbSelectVendor.Focus();
                return;
            }

            if (cmbSelectPayment.SelectedIndex == 1)
            {
                if (txtDays.Text.Trim().Length == 0)
                {
                    ep.SetError(txtDays, "Please enter number of days!");
                    txtDays.Focus();
                    return;
                }
            }

            if (txtGauge.Text.Trim().Length == 0)
            {
                ep.SetError(txtGauge, "Please enter product name!");
                txtGauge.Focus();
                return;
            }

            if (txtThickness.Text.Trim().Length == 0)
            {
                ep.SetError(txtThickness, "Please enter thickness!");
                txtThickness.Focus();
                return;
            }

            if (txtWidth.Text.Trim().Length == 0)
            {
                ep.SetError(txtWidth, "Please enter width!");
                txtWidth.Focus();
                return;
            }

            if (txtLocation.Text.Trim().Length == 0)
            {
                ep.SetError(txtLocation, "Please enter location!");
                txtLocation.Focus();
                return;
            }

            if (int.Parse(txtUnitPrice.Text.Trim()) == 0)
            {
                ep.SetError(txtUnitPrice, "Please enter nuit price!");
                txtUnitPrice.Focus();
                return;
            }

            if (txtOrigin.Text.Trim().Length == 0)
            {
                ep.SetError(txtOrigin, "Please enter origin!");
                txtOrigin.Focus();
                return;
            }

            DataTable dt = new DataTable();
            dt = DatabaseAccess.Retrieve("select * from PurchaseTable where RefNo = '" + txtRefNo.Text.Trim() + "' AND Coil_ID != '" + txtCoilID.Text.Trim() + "'");
            if (dt != null)
            {
                if (dt.Rows.Count > 0)
                {
                    ep.SetError(txtRefNo, "Already exists!");
                    txtRefNo.Focus();
                    return;
                }
            }
            if (txtDays.Enabled == true && dtpDueDate.Enabled == true)
            {
                string query = string.Format("update PurchaseTable set RefNo = '{0}', Vendor_ID = '{1}', Gauge = '{2}', Thickness = '{3}', Width = '{4}', UnitPrice = '{5}', Date = '{6}', Origin = '{7}', Payment = '{8}', DeliveryFrom = '{9}', Days = '{10}', DueDate = '{11}', Coil_ID = '{12}' where ID = '{13}'", txtRefNo.Text.Trim(), cmbSelectVendor.SelectedValue, txtGauge.Text.Trim(), txtThickness.Text.Trim(), txtWidth.Text.Trim(), txtUnitPrice.Text.Trim(), dtpDate.Value.ToString("yyyy/MM/dd"), txtOrigin.Text.Trim(), cmbSelectPayment.SelectedItem, txtLocation.Text.Trim(), txtDays.Text.Trim(), dtpDueDate.Value.ToString("yyyy/MM/dd"), txtCoilID.Text.Trim(), dgvPurchaseList.CurrentRow.Cells[0].Value);
                bool result = DatabaseAccess.Update(query);
                if (result)
                {
                    MessageBox.Show("Updated successfully!");
                    FillGrid("");
                    DisableControls();
                }
                else
                {
                    MessageBox.Show("Error!");
                }
            }
            else
            {
                string query = string.Format("update PurchaseTable set RefNo = '{0}', Vendor_ID = '{1}', Gauge = '{2}', Thickness = '{3}', Width = '{4}', UnitPrice = '{5}', Date = '{6}', Origin = '{7}', Payment = '{8}', DeliveryFrom = '{9}', Days = '{10}', DueDate = '{11}', Coil_ID = '{12}' where ID = '{13}'", txtRefNo.Text.Trim(), cmbSelectVendor.SelectedValue, txtGauge.Text.Trim(), txtThickness.Text.Trim(), txtWidth.Text.Trim(), txtUnitPrice.Text.Trim(), dtpDate.Value.ToString("yyyy/MM/dd"), txtOrigin.Text.Trim(), cmbSelectPayment.SelectedItem, txtLocation.Text.Trim(), '0', dtpDate.Value.ToString("yyyy/MM/dd"), txtCoilID.Text.Trim(), dgvPurchaseList.CurrentRow.Cells[0].Value);
                bool result = DatabaseAccess.Update(query);
                if (result)
                {
                    MessageBox.Show("Updated successfully!");
                    FillGrid("");
                    DisableControls();
                }
                else
                {
                    MessageBox.Show("Error!");
                }
            }

            
        }

        private void DisableControls()
        {
            btnSave.Enabled = true;
            btnPrint.Enabled = true;
            btnEdit.Enabled = false;
            txtSearch.Enabled = true;
            btnCancel.Enabled = false;
            dgvPurchaseList.Enabled = true;
            FillGrid("");
        }

        private void EnableControls()
        {
            btnSave.Enabled = false;
            btnPrint.Enabled = false;
            btnEdit.Enabled = true;
            txtSearch.Enabled = false;
            btnCancel.Enabled = true;
            dgvPurchaseList.Enabled = false;
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            DisableControls();
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtRefNo.Clear();
            txtGauge.Clear();
            txtCoilID.Clear();
            txtThickness.Clear();
            txtWidth.Clear();
            txtUnitPrice.Clear();
            txtOrigin.Clear();
            cmbSelectPayment.SelectedIndex = 0;
            dtpDate.Value = DateTime.Today;
            dtpDueDate.Value = DateTime.Today;
            txtDays.Clear();
            cmbSelectVendor.SelectedIndex = 0;
            txtLocation.Clear();
        }

        private void btnPrint_Click(object sender, EventArgs e)
        {
            if (dgvPurchaseList.Rows.Count > 0)
            {
                SaveFileDialog save = new SaveFileDialog();
                save.Filter = "PDF (*.pdf)|*.pdf";
                save.FileName = "Stock.pdf";
                bool ErrorMessage = false;

                if (save.ShowDialog() == DialogResult.OK)
                {
                    if (File.Exists(save.FileName))
                    {
                        try
                        {
                            File.Delete(save.FileName);
                        } 
                        catch (Exception ex)
                        {
                            ErrorMessage = true;
                            MessageBox.Show("Unable to write file onto disk!" + ex.Message);
                        }
                    }
                    if (!ErrorMessage)
                    {
                        try
                        {
                            PdfPTable pTable = new PdfPTable(dgvPurchaseList.Columns.Count);
                            pTable.DefaultCell.Padding = 2;
                            pTable.WidthPercentage = 100;
                            pTable.HorizontalAlignment = Element.ALIGN_LEFT;

                            foreach (DataGridViewColumn col in dgvPurchaseList.Columns)
                            {
                                PdfPCell pCell = new PdfPCell(new Phrase(col.HeaderText));
                                pTable.AddCell(pCell);
                            }
                            foreach (DataGridViewRow viewRow in dgvPurchaseList.Rows)
                            {
                                foreach (DataGridViewCell dcell in viewRow.Cells)
                                {
                                    pTable.AddCell(dcell.Value.ToString());
                                }
                            }

                            using (FileStream fileStream = new FileStream(save.FileName, FileMode.Create))
                            {
                                Document document = new Document(new iTextSharp.text.Rectangle(288f, 144f), 10, 10, 10, 10);
                                document.SetPageSize(iTextSharp.text.PageSize.A4.Rotate());
                                PdfWriter.GetInstance(document, fileStream);
                                document.Open();
                                document.Add(pTable);
                                document.Close();
                                fileStream.Close();
                            }
                            MessageBox.Show("Data exported successfully!", "info");
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show("Error while exporting data!" + ex.Message);
                        }
                    }
                }
            }
            else
            {
                MessageBox.Show("No record found!", "info");
            }
        }

        private void btnAddVendor_Click(object sender, EventArgs e)
        {
            Vendors frm = new Vendors();
            frm.ShowDialog();
            btnRefresh_Click(sender, e);
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            ComboHelper.FillVendors(cmbSelectVendor);
        }

        private void cmbSelectPayment_SelectedIndexChanged(object sender, EventArgs e)
        {
            
            string val = cmbSelectPayment.SelectedItem.ToString();
            if (val == "Credit")
            {
                txtDays.Enabled = true;
                dtpDueDate.Enabled = true;
            }
            else
            {
                txtDays.Enabled = false;
                dtpDueDate.Enabled = false;
            }
        }

        private void txtDays_TextChanged(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtDays.Text))
            {
                txtDays.Text = "0";
            }
            dtpDueDate.Value = DateTime.Today.AddDays(Convert.ToInt16(txtDays.Text.Trim()));
        }
    }
}
