﻿namespace Inventory_System.Forms.StockForms
{
    partial class CuttingOrders
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.dgvCuttingOrdersList = new System.Windows.Forms.DataGridView();
            this.txtSearch = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.doneToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.label15 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dgvCuttingOrdersList)).BeginInit();
            this.contextMenuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // dgvCuttingOrdersList
            // 
            this.dgvCuttingOrdersList.AllowUserToAddRows = false;
            this.dgvCuttingOrdersList.AllowUserToResizeColumns = false;
            this.dgvCuttingOrdersList.AllowUserToResizeRows = false;
            this.dgvCuttingOrdersList.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgvCuttingOrdersList.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.dgvCuttingOrdersList.BackgroundColor = System.Drawing.SystemColors.ButtonFace;
            this.dgvCuttingOrdersList.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgvCuttingOrdersList.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvCuttingOrdersList.Location = new System.Drawing.Point(20, 153);
            this.dgvCuttingOrdersList.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.dgvCuttingOrdersList.MultiSelect = false;
            this.dgvCuttingOrdersList.Name = "dgvCuttingOrdersList";
            this.dgvCuttingOrdersList.ReadOnly = true;
            this.dgvCuttingOrdersList.RowHeadersVisible = false;
            this.dgvCuttingOrdersList.RowTemplate.Height = 24;
            this.dgvCuttingOrdersList.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvCuttingOrdersList.Size = new System.Drawing.Size(1360, 586);
            this.dgvCuttingOrdersList.TabIndex = 1;
            // 
            // txtSearch
            // 
            this.txtSearch.Location = new System.Drawing.Point(123, 113);
            this.txtSearch.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtSearch.Name = "txtSearch";
            this.txtSearch.Size = new System.Drawing.Size(319, 22);
            this.txtSearch.TabIndex = 0;
            this.txtSearch.TextChanged += new System.EventHandler(this.txtSearch_TextChanged);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(19, 113);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(89, 17);
            this.label9.TabIndex = 11;
            this.label9.Text = "Search by ID";
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.doneToolStripMenuItem});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(194, 28);
            // 
            // doneToolStripMenuItem
            // 
            this.doneToolStripMenuItem.Name = "doneToolStripMenuItem";
            this.doneToolStripMenuItem.Size = new System.Drawing.Size(193, 24);
            this.doneToolStripMenuItem.Text = "Received at Shop";
            this.doneToolStripMenuItem.Click += new System.EventHandler(this.doneToolStripMenuItem_Click);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 22F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(569, 32);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(274, 42);
            this.label15.TabIndex = 13;
            this.label15.Text = "Cutting Orders";
            // 
            // CuttingOrders
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1412, 704);
            this.ContextMenuStrip = this.contextMenuStrip1;
            this.Controls.Add(this.label15);
            this.Controls.Add(this.dgvCuttingOrdersList);
            this.Controls.Add(this.txtSearch);
            this.Controls.Add(this.label9);
            this.Name = "CuttingOrders";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Cutting Orders";
            this.Load += new System.EventHandler(this.CuttingOrders_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvCuttingOrdersList)).EndInit();
            this.contextMenuStrip1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dgvCuttingOrdersList;
        private System.Windows.Forms.TextBox txtSearch;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem doneToolStripMenuItem;
        private System.Windows.Forms.Label label15;
    }
}