﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Inventory_System.Forms.StockForms
{
    public partial class Warehouse : Form
    {
        public Warehouse()
        {
            InitializeComponent();
        }

        private void Warehouse_Load(object sender, EventArgs e)
        {
            FillGrid("");
        }

        public void FillGrid(string searchvalue)
        {
            string query = string.Empty;
            DataTable dt = new DataTable();
            if (string.IsNullOrEmpty(searchvalue) && string.IsNullOrWhiteSpace(searchvalue))
            {
                query = "select * from v_Inventory where Status = 'complete'";

            }
            else
            {
                query = "select * from v_Inventory where Status = 'complete' AND Ref# like '%" + searchvalue + "%'";
            }
            dt = DatabaseAccess.Retrieve(query);
            if (dt != null)
            {
                if (dt.Rows.Count > 0)
                {
                    dgvInventoryList.DataSource = dt;
                }
                else
                {
                    dgvInventoryList.DataSource = null;
                }
            }
            else
            {
                dgvInventoryList.DataSource = null;
            }
        }

        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            FillGrid(txtSearch.Text.Trim());
        }

        private void sendToCutterToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Cutter frm = new Cutter(this);
            frm.ShowDialog();
        }
    }
}
