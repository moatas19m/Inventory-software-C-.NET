﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Inventory_System.Forms.StockForms
{
    public partial class CuttingOrders : Form
    {
        public CuttingOrders()
        {
            InitializeComponent();
        }
        private void FillGrid(string searchvalue)
        {
            string query = string.Empty;
            DataTable dt = new DataTable();
            if (string.IsNullOrEmpty(searchvalue) && string.IsNullOrWhiteSpace(searchvalue))
            {
                query = "select * from CuttingOrdersTable";

            }
            else
            {
                query = "select * from CuttingOrdersTable where (ref_no) like '%" + searchvalue + "%'";
            }
            dt = DatabaseAccess.Retrieve(query);
            if (dt != null)
            {
                if (dt.Rows.Count > 0)
                {
                    dgvCuttingOrdersList.DataSource = dt;

                }
                else
                {
                    dgvCuttingOrdersList.DataSource = null;
                }
            }
            else
            {
                dgvCuttingOrdersList.DataSource = null;
            }
        }

        private void CuttingOrders_Load(object sender, EventArgs e)
        {
            FillGrid("");
        }

        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            FillGrid(txtSearch.Text.Trim());
        }

       
        private void doneToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string query = string.Format("update CuttingOrders set Status = '{0}' where Ref_No = '{1}'", "Recieved",dgvCuttingOrdersList.CurrentRow.Cells[1].Value);

            bool result = DatabaseAccess.Update(query);
            if (result)
            {
                MessageBox.Show("Recieved at shop!");
                FillGrid("");
            }
            else
            {
                MessageBox.Show("Error!");
            }
        }
    }
}
