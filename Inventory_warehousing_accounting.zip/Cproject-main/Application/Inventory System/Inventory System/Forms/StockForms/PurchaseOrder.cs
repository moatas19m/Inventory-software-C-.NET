﻿using Inventory_System.SourceCode;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Inventory_System.Forms.StockForms
{
    public partial class PurchaseOrder : Form
    {
        private receiveInventory frm1;

        public PurchaseOrder(receiveInventory frm)
        {
            InitializeComponent();
            frm1 = frm;
        }

        private void PurchaseOrder_Load(object sender, EventArgs e)
        {
            ComboHelper.FillVendors(cmbSelectTransporter);
            cmbSelectTransporter.SelectedIndex = 0;
            ComboHelper.FillSites(cmbSelectSite);
            cmbSelectSite.SelectedIndex = 0;
            ComboHelper.FillTransporters(cmbSelectTransporter);
            cmbSelectTransporter.SelectedIndex = 0;

            receiveInventory frm = (receiveInventory)Application.OpenForms["receiveInventory"];
            int row =frm.dgvPurchaseOrdersList.CurrentRow.Index;

            txtCoilID.Text = Convert.ToString(frm.dgvPurchaseOrdersList[2, row].Value);
            txtRefNo.Text = Convert.ToString(frm.dgvPurchaseOrdersList[3, row].Value);
            txtVendor.Text = Convert.ToString(frm.dgvPurchaseOrdersList[4, row].Value);
            txtGauge.Text = Convert.ToString(frm.dgvPurchaseOrdersList[6, row].Value);
            txtThickness.Text = Convert.ToString(frm.dgvPurchaseOrdersList[7, row].Value);
            txtWidth.Text = Convert.ToString(frm.dgvPurchaseOrdersList[8, row].Value);
            txtUnitPrice.Text = Convert.ToString(frm.dgvPurchaseOrdersList[9, row].Value);

            var onlyDate = Convert.ToString(frm.dgvPurchaseOrdersList[5, row].Value).Split(' ');
            txtDate.Text = onlyDate[0];

            txtLocation.Text = Convert.ToString(frm.dgvPurchaseOrdersList[10, row].Value);
            txtOrigin.Text = Convert.ToString(frm.dgvPurchaseOrdersList[11, row].Value);
            txtPayment.Text = Convert.ToString(frm.dgvPurchaseOrdersList[12, row].Value);
            txtDays.Text = Convert.ToString(frm.dgvPurchaseOrdersList[13, row].Value);

            var onlyDueDate = Convert.ToString(frm.dgvPurchaseOrdersList[14, row].Value).Split(' ');
            txtDueDate.Text = onlyDueDate[0];
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            ComboHelper.FillVendors(cmbSelectTransporter);
        }

        private void btnAddVendor_Click(object sender, EventArgs e)
        {
            Vendors frm = new Vendors();
            frm.ShowDialog();
            btnRefresh_Click(sender, e);
        }

        private void txtTransportCost_TextChanged(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtTransportCost.Text))
            {
                txtTransportCost.Text = "0";
            }

            if (!string.IsNullOrEmpty(txtWeight.Text) && !string.IsNullOrEmpty(txtUnitPrice.Text) && !string.IsNullOrEmpty(txtTransportCost.Text))
            {
                float TotalPrice = 0;
                TotalPrice = (float.Parse(txtWeight.Text) * float.Parse(txtUnitPrice.Text));
                TotalPrice = TotalPrice + float.Parse(txtTransportCost.Text);
                txtLandedCost.Text = TotalPrice.ToString();
            }
        }

        private void txtweight_TextChanged(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtWeight.Text))
            {
                txtWeight.Text = "0";
            }

            if (!string.IsNullOrEmpty(txtWeight.Text) && !string.IsNullOrEmpty(txtUnitPrice.Text) && !string.IsNullOrEmpty(txtTransportCost.Text))
            {
                float TotalPrice = 0;
                TotalPrice = float.Parse(txtWeight.Text) * float.Parse(txtUnitPrice.Text);
                TotalPrice = TotalPrice + float.Parse(txtTransportCost.Text);
                txtLandedCost.Text = TotalPrice.ToString();
            }
        }

        private void btnConfirm_Click(object sender, EventArgs e)
        {
            receiveInventory frm = (receiveInventory)Application.OpenForms["receiveInventory"];

            ep.Clear();

            if (int.Parse(txtWeight.Text.Trim()) == 0)
            {
                ep.SetError(txtRefNo, "Please enter weight!");
                txtWeight.Focus();
                return;
            }

            if (cmbSelectTransporter.SelectedIndex == 0)
            {
                ep.SetError(cmbSelectTransporter, "Please enter transporter name!");
                cmbSelectTransporter.Focus();
                return;
            }

            if (cmbSelectSite.SelectedIndex == 0)
            {
                ep.SetError(cmbSelectSite, "Please enter site!");
                cmbSelectSite.Focus();
                return;
            }

            string updatequery = string.Format("update PurchaseTable set WeightperTon = '{0}', TransportCostperTon = '{1}', Transporter_ID = '{2}', ShippedTo_ID = '{3}', LandedCost = '{4}', Status = '{5}', CurrentWeight = '{6}' where RefNo = '{7}'", txtWeight.Text.Trim(), txtTransportCost.Text.Trim(), cmbSelectTransporter.SelectedValue, cmbSelectSite.SelectedValue, txtLandedCost.Text.Trim(), "complete", txtWeight.Text.Trim(), txtRefNo.Text.Trim());
            bool result = DatabaseAccess.Update(updatequery);

            if (result)
            {
                MessageBox.Show("Purchase confirmed!");
                frm.FillGrid("");
                Products frmP = new Products();
                frmP.FillGrid("");
                this.Close();
            }
            else
            {
                MessageBox.Show("Error");
            }
        }
    }
}
