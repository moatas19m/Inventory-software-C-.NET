﻿using Inventory_System.Forms.Settings;
using Inventory_System.Forms.StockForms;
using Inventory_System.Forms.UserForms;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Inventory_System
{
    public partial class mainForm : Form
    {
        userTypes UserTypesForm;
        Products ProductForms;
        CuttingOrders CuttingOrdersForm;
        Warehouse WarehouseForm;
        receiveInventory receiveInventoryForm;

        public mainForm()
        {
            InitializeComponent();
        }

        private void mainForm_Load(object sender, EventArgs e)
        {
            tsbLogin.Visible = true;
            tsbLogout.Visible = false;
            msall.Enabled = false;
        }

        private void userTypesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (UserTypesForm == null)
            {
                UserTypesForm = new userTypes();
            }
            UserTypesForm.ShowDialog();
        }

        private void addUserToolStripMenuItem_Click(object sender, EventArgs e)
        {
            addUsers frm = new addUsers();
            frm.ShowDialog();
        }

        private void tsbLogin_Click(object sender, EventArgs e)
        {
            LoginForm frm = new LoginForm(this);
            frm.ShowDialog();
        }

        private void tsbLogout_ButtonClick(object sender, EventArgs e)
        {
            Application.Restart();
        }

        private void changePasswordToolStripMenuItem_Click(object sender, EventArgs e)
        {
            UpdateUser frm = new UpdateUser();
            frm.ShowDialog();
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void logoutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Restart();
        }

        private void logoutToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            Application.Restart();
        }

        private void productsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (WarehouseForm == null)
            {
                WarehouseForm = new Warehouse();
            }
            WarehouseForm.TopLevel = false;
            panelparent.Controls.Remove(ProductForms);
            panelparent.Controls.Remove(CuttingOrdersForm);
            panelparent.Controls.Remove(receiveInventoryForm);
            panelparent.Controls.Add(WarehouseForm);
            WarehouseForm.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            WarehouseForm.Dock = DockStyle.Fill;
            WarehouseForm.Show();
        }

        private void newPurchaseToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (ProductForms == null)
            {
                ProductForms = new Products();
            }
            ProductForms.TopLevel = false;
            panelparent.Controls.Remove(WarehouseForm);
            panelparent.Controls.Remove(CuttingOrdersForm);
            panelparent.Controls.Remove(receiveInventoryForm);
            panelparent.Controls.Add(ProductForms);
            ProductForms.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            ProductForms.Dock = DockStyle.Fill;
            ProductForms.Show();
        }

        private void cuttingOrdersToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            if (CuttingOrdersForm == null)
            {
                CuttingOrdersForm = new CuttingOrders();
            }
            CuttingOrdersForm.TopLevel = false;
            panelparent.Controls.Remove(WarehouseForm);
            panelparent.Controls.Remove(ProductForms);
            panelparent.Controls.Remove(receiveInventoryForm);
            panelparent.Controls.Add(CuttingOrdersForm);
            CuttingOrdersForm.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            CuttingOrdersForm.Dock = DockStyle.Fill;
            CuttingOrdersForm.Show();
        }

        private void vendorsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Vendors frm = new Vendors();
            frm.ShowDialog();
        }

        private void vendorsToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            Vendors frm = new Vendors();
            frm.ShowDialog();
        }

        private void receiveInventoryToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (receiveInventoryForm == null)
            {
                receiveInventoryForm = new receiveInventory();
            }
            receiveInventoryForm.TopLevel = false;
            panelparent.Controls.Remove(WarehouseForm);
            panelparent.Controls.Remove(ProductForms);
            panelparent.Controls.Remove(CuttingOrdersForm);
            panelparent.Controls.Add(receiveInventoryForm);
            receiveInventoryForm.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            receiveInventoryForm.Dock = DockStyle.Fill;
            receiveInventoryForm.Show();
        }

        private void sitesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Sites frm = new Sites();
            frm.ShowDialog();
        }

        private void categoriesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Categories frm = new Categories();
            frm.ShowDialog();
        }

        private void transportersToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Transporters frm = new Transporters();
            frm.ShowDialog();
        }
    }
}
