﻿using Inventory_System.SourceCode;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Inventory_System.Forms.UserForms
{
    public partial class UpdateUser : Form
    {
        public UpdateUser()
        {
            InitializeComponent();           
        }

        private void UpdateUser_Load(object sender, EventArgs e)
        {
            ComboHelper.FillUserTypes(cmbSelectUserType);
            if (CurrentUser.UserID > 0)
            {
                cmbSelectUserType.SelectedValue = CurrentUser.UserType_ID;
                txtFullName.Text = CurrentUser.FullName;
                txtContactNo.Text = CurrentUser.ContactNo;
                txtEmail.Text = CurrentUser.Email;
                txtUserName.Text = CurrentUser.UserName;
            }
        }

        private void btnAddUserType_Click(object sender, EventArgs e)
        {
            userTypes frm = new userTypes();
            frm.ShowDialog();
            btnRefresh_Click(sender, e);
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            ComboHelper.FillUserTypes(cmbSelectUserType);
        }

        private void ClearForm()
        {
            cmbSelectUserType.SelectedIndex = 0;
            txtEmail.Clear();
            txtContactNo.Clear();
            txtFullName.Clear();
            txtPassword.Clear();
            txtUserName.Clear();
            txtOldPassword.Clear();
            txtConfirmPassword.Clear();
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            ep.Clear();
            if (cmbSelectUserType.SelectedIndex == 0)
            {
                ep.SetError(cmbSelectUserType, "Please select user type!");
                cmbSelectUserType.Focus();
                return;
            }

            if (txtFullName.Text.Trim().Length == 0)
            {
                ep.SetError(txtFullName, "Please enter full name");
                txtFullName.Focus();
                return;
            }

            if (txtContactNo.Text.Trim().Length == 0)
            {
                ep.SetError(txtContactNo, "Please enter contact no");
                txtContactNo.Focus();
                return;
            }

            if (txtUserName.Text.Trim().Length == 0)
            {
                ep.SetError(txtUserName, "Please enter user name");
                txtUserName.Focus();
                return;
            }

            if (txtOldPassword.Text.Trim().Length == 0)
            {
                ep.SetError(txtOldPassword, "Please enter your current/old password!");
                txtOldPassword.Focus();
                return;
            }

            if (txtPassword.Text.Trim().Length > 0 || txtConfirmPassword.Text.Trim().Length > 0) 
            {
                if (txtPassword.Text.Trim().Length == 0)
                {
                    ep.SetError(txtPassword, "Please enter new password");
                    txtPassword.Focus();
                    return;
                }

                if (txtConfirmPassword.Text.Trim().Length == 0)
                {
                    ep.SetError(txtConfirmPassword, "Please confirm new password");
                    txtConfirmPassword.Focus();
                    return;
                }

                if (txtPassword.Text.Trim() != txtConfirmPassword.Text.Trim())
                {
                    ep.SetError(txtConfirmPassword, "Password does not match");
                    txtConfirmPassword.Focus();
                    return;
                }
            }


            DataTable dt = DatabaseAccess.Retrieve("select * from UsersTable where UserName = '" + txtUserName + "' and UserID != '"+CurrentUser.UserID+"'");
            if (dt != null)
            {
                if (dt.Rows.Count > 0)
                {
                    ep.SetError(txtUserName, "User name already exists!");
                    txtUserName.Focus();
                    return;
                }
            }

            dt = null;

            dt = DatabaseAccess.Retrieve("select * from UsersTable where FullName = '" + txtFullName.Text.Trim() + "' and ContactNo = '" + txtContactNo.Text.Trim() + "' and UserID != '"+CurrentUser.UserID+"'");
            if (dt != null)
            {
                if (dt.Rows.Count > 0)
                {
                    ep.SetError(txtFullName, "User already exists!");
                    txtFullName.Focus();
                    return;
                }
            }

            dt = DatabaseAccess.Retrieve("select Password from UsersTable where UserID = '"+CurrentUser.UserID+"'");
            if (dt != null)
            {

                if (dt.Rows.Count > 0)
                {
                    if (Convert.ToString(dt.Rows[0]["Password"]) != txtOldPassword.Text.Trim())
                    {
                        ep.SetError(txtOldPassword, "Password is incorrect!");
                        txtOldPassword.Focus();
                        return;
                    }
                }
                else
                {
                    ep.SetError(txtOldPassword, "Password is incorrect!");
                    txtOldPassword.Focus();
                    return;
                }
            }
            else
            {
                ep.SetError(txtOldPassword, "Password is incorrect!");
                txtOldPassword.Focus();
                return;
            }

            string updatequery = string.Empty;
            if (txtPassword.Text.Trim().Length > 0 && txtConfirmPassword.Text.Trim().Length > 0)
            {
                updatequery = string.Format("update UsersTable set Usertype_ID = '{0}', FullName = '{1}', Email = '{2}', ContactNo = '{3}', UserName = '{4}', Password = '{5}' where UserID = '"+CurrentUser.UserID+"'", cmbSelectUserType.SelectedValue, txtFullName.Text.Trim(), txtEmail.Text.Trim(), txtContactNo.Text.Trim(), txtUserName.Text.Trim(), txtPassword.Text.Trim());
            }
            else
            {
                updatequery = string.Format("update UsersTable set Usertype_ID = '{0}', FullName = '{1}', Email = '{2}', ContactNo = '{3}', UserName = '{4}' where UserID = '" + CurrentUser.UserID + "'", cmbSelectUserType.SelectedValue, txtFullName.Text.Trim(), txtEmail.Text.Trim(), txtContactNo.Text.Trim(), txtUserName.Text.Trim());
            }


            bool result = DatabaseAccess.Update(updatequery);
            if (result)
            {
                MessageBox.Show("Details updated successfully");
                RetriveUserInfo();
                this.Close();
            }
            else
            {
                MessageBox.Show("Error");
            }
        }

        private void RetriveUserInfo()
        {
            string password = string.Empty;
            if (txtPassword.Text.Trim().Length > 0)
            {
                password = txtPassword.Text.Trim();
            }
            else
            {
                password = txtOldPassword.Text.Trim();
            }

            string getquery = "select UserID, UserType_ID, FullName, Email, ContactNo, UserName from UsersTable where UserName  = '" + txtUserName.Text.Trim() + "' and  Password = '" + password + "'";
            DataTable dt = DatabaseAccess.Retrieve(getquery);
            if (dt.Rows.Count > 0)
            {
                CurrentUser.UserID = Convert.ToInt32(dt.Rows[0]["UserID"]);
                CurrentUser.UserType_ID = Convert.ToInt32(dt.Rows[0]["UserType_ID"]);
                CurrentUser.FullName = Convert.ToString(dt.Rows[0]["FullName"]);
                CurrentUser.Email = Convert.ToString(dt.Rows[0]["Email"]);
                CurrentUser.ContactNo = Convert.ToString(dt.Rows[0]["ContactNo"]);
                CurrentUser.UserName = Convert.ToString(dt.Rows[0]["UserName"]);
            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            ClearForm();
        }
    }
}
