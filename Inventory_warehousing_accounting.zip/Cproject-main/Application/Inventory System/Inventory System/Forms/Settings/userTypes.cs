﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Inventory_System
{
    public partial class userTypes : Form
    {
        public userTypes()
        {
            InitializeComponent();
        }

        private void FillGrid(string searchvalue)
        {
            string query = string.Empty;
            DataTable dt = new DataTable();
            if (string.IsNullOrEmpty(searchvalue) && string.IsNullOrWhiteSpace(searchvalue))
            {
                query = "select UserTypeID [ID], UserType [User Type] from UserTypesTable";

            }
            else
            {
                query = "select UserTypeID [ID], UserType [User Type] from UserTypesTable where UserType like '%"+searchvalue+"%'";
            }
            dt = DatabaseAccess.Retrieve(query);
            if (dt != null)
            {
                if (dt.Rows.Count > 0)
                {
                    dvgUserType.DataSource = dt;
                    dvgUserType.Columns[0].Width = 100;
                    dvgUserType.Columns[1].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
                }
                else
                {
                    dvgUserType.DataSource = null;
                }
            }else
            {
                dvgUserType.DataSource = null;
            }
        }

        private void userTypes_Load(object sender, EventArgs e)
        {
            FillGrid("");
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            ep.Clear();
            if (txtEnterUserType.Text.Trim().Length == 0)
            {
                ep.SetError(txtEnterUserType, "Please enter user type");
                txtEnterUserType.Focus();
                return;
            }

            string query = string.Format("insert into UserTypesTable(UserType) values('{0}')", txtEnterUserType.Text.Trim());
            bool result = DatabaseAccess.Insert(query);
            if (result)
            {
                MessageBox.Show("Saved successfully");
                FillGrid("");
            }
            else
            {
                MessageBox.Show("Error");
            }
        }

        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            FillGrid(txtSearch.Text.Trim());
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtEnterUserType.Clear();
        }

        private void editToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (dvgUserType != null)
            {
                if (dvgUserType.Rows.Count > 0)
                {
                    if (dvgUserType.SelectedRows.Count == 1)
                    {
                        txtEnterUserType.Text = Convert.ToString(dvgUserType.CurrentRow.Cells[1].Value);
                        EnableControls();
                    }
                    else
                    {
                        MessageBox.Show("Please select a record");
                    }
                }
                else
                {
                    MessageBox.Show("List is empty");
                }
            }
        }

        private void EnableControls()
        {
            btnEdit.Enabled = true;
            btnCancel.Enabled = true;
            btnSave.Enabled = false;
            dvgUserType.Enabled = false;
            txtSearch.Enabled = false;
        }

        private void DisableControls()
        {
            btnEdit.Enabled = false;
            btnCancel.Enabled = false;
            btnSave.Enabled = true;
            dvgUserType.Enabled = true;
            txtSearch.Enabled = true;
            FillGrid("");
            txtEnterUserType.Clear();
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            ep.Clear();
            if (txtEnterUserType.Text.Trim().Length == 0)
            {
                ep.SetError(txtEnterUserType, "Please enter user type");
                txtEnterUserType.Focus();
                return;
            }

            string query = string.Format("update UserTypesTable set UserType = '{0}' where UserTypeID = '{1}'", txtEnterUserType.Text.Trim(), Convert.ToString(dvgUserType.CurrentRow.Cells[0].Value));
            bool result = DatabaseAccess.Update(query);
            if (result)
            {
                MessageBox.Show("Updated successfully");
                DisableControls();
            }
            else
            {
                MessageBox.Show("Error");
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            DisableControls();
        }

        private void deleteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (dvgUserType != null)
            {
                if (dvgUserType.Rows.Count > 0)
                {
                    if (dvgUserType.SelectedRows.Count == 1)
                    {
                        if (MessageBox.Show("Are you sure you want to delete selected record?", "Confirmation", MessageBoxButtons.YesNo,MessageBoxIcon.Question) == DialogResult.Yes)
                        {
                            bool result = DatabaseAccess.Delete("delete from UserTypesTable where UserTypeID = '"+dvgUserType.CurrentRow.Cells[0].Value+"'");
                            if (result)
                            {
                                FillGrid("");
                                MessageBox.Show("Record deleted successfully");
                            }
                            else
                            {
                                MessageBox.Show("Error");
                            }
                        }
                    }
                    else
                    {
                        MessageBox.Show("Please select a record");
                    }
                }
                else
                {
                    MessageBox.Show("List is empty");
                }
            }
        }
    }
}
