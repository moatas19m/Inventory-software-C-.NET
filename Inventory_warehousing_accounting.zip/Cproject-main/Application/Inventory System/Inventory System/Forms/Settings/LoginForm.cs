﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Inventory_System.Forms.UserForms
{
    public partial class LoginForm : Form
    {
        private mainForm mainform;

        public LoginForm()
        {
            InitializeComponent();
        }

        public LoginForm(mainForm frmmainForm)
        {
            InitializeComponent();
            this.mainform = frmmainForm;
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            lblError.Visible = false;
            ep.Clear();
            if (txtUserName.Text.Trim().Length == 0)
            {
                ep.SetError(txtUserName, "Please enter your username!");
                txtUserName.Focus();
                return;
            }

            if (txtPassword.Text.Trim().Length == 0)
            {
                ep.SetError(txtPassword, "Please enter password!");
                txtPassword.Focus();
                return;
            }

            string getquery = "select UserID, UserType_ID, FullName, Email, ContactNo, UserName from UsersTable where UserName  = '"+txtUserName.Text.Trim()+"' and  Password = '"+txtPassword.Text.Trim()+"'";
            DataTable dt = DatabaseAccess.Retrieve(getquery);
            if (dt == null)
            {
                lblError.Visible = true;
                mainform.tsbLogin.Visible = true;
                mainform.tsbLogout.Visible = false;
                mainform.msall.Enabled = false;
                return;
            }
            else if (dt.Rows.Count > 0)
            {
                // visible controls
                mainform.tsbLogin.Visible = false;
                mainform.tsbLogout.Visible = true;
                mainform.msall.Enabled = true;
                CurrentUser.UserID = Convert.ToInt32(dt.Rows[0]["UserID"]);
                CurrentUser.UserType_ID = Convert.ToInt32(dt.Rows[0]["UserType_ID"]);
                CurrentUser.FullName = Convert.ToString(dt.Rows[0]["FullName"]);
                CurrentUser.Email = Convert.ToString(dt.Rows[0]["Email"]);
                CurrentUser.ContactNo = Convert.ToString(dt.Rows[0]["ContactNo"]);
                CurrentUser.UserName = Convert.ToString(dt.Rows[0]["UserName"]);
                this.Close();
                return;
            }
            else
            {
                lblError.Visible = true;
            }
        }
    }
}
