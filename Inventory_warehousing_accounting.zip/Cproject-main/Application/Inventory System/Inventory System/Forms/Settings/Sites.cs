﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Inventory_System.Forms.Settings
{
    public partial class Sites : Form
    {
        public Sites()
        {
            InitializeComponent();
        }

        private void FillGrid(string searchvalue)
        {
            string query = string.Empty;
            DataTable dt = new DataTable();
            if (string.IsNullOrEmpty(searchvalue) && string.IsNullOrWhiteSpace(searchvalue))
            {
                query = "select SiteID [ID], SiteName [Site Name] from SiteTable";

            }
            else
            {
                query = "select SiteID [ID], SiteName [Site Name] from SiteTable where SiteName like '%" + searchvalue + "%'";
            }
            dt = DatabaseAccess.Retrieve(query);
            if (dt != null)
            {
                if (dt.Rows.Count > 0)
                {
                    dgvSiteList.DataSource = dt;
                    dgvSiteList.Columns[0].Width = 100;
                    dgvSiteList.Columns[1].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
                }
                else
                {
                    dgvSiteList.DataSource = null;
                }
            }
            else
            {
                dgvSiteList.DataSource = null;
            }
        }

        private void Sites_Load(object sender, EventArgs e)
        {
            FillGrid("");
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            DisableControls();
        }

        private void EnableControls()
        {
            btnEdit.Enabled = true;
            btnCancel.Enabled = true;
            btnSave.Enabled = false;
            dgvSiteList.Enabled = false;
            txtSearch.Enabled = false;
        }

        private void DisableControls()
        {
            btnEdit.Enabled = false;
            btnCancel.Enabled = false;
            btnSave.Enabled = true;
            dgvSiteList.Enabled = true;
            txtSearch.Enabled = true;
            FillGrid("");
            txtSite.Clear();
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtSite.Clear();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            ep.Clear();
            if (txtSite.Text.Trim().Length == 0)
            {
                ep.SetError(txtSite, "Please enter site name");
                txtSite.Focus();
                return;
            }

            DataTable dt = new DataTable();
            dt = DatabaseAccess.Retrieve("select * from SiteTable where SiteName = '" + txtSite.Text.Trim() + "'");

            if (dt != null)
            {
                if (dt.Rows.Count > 0)
                {
                    ep.SetError(txtSite, "Already exists!");
                    txtSite.Focus();
                    return;
                }
            }

            string query = string.Format("insert into SiteTable(SiteName) values('{0}')", txtSite.Text.Trim());
            bool result = DatabaseAccess.Insert(query);
            if (result)
            {
                MessageBox.Show("Saved successfully");
                FillGrid("");
            }
            else
            {
                MessageBox.Show("Error");
            }
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            ep.Clear();
            if (txtSite.Text.Trim().Length == 0)
            {
                ep.SetError(txtSite, "Please enter site name");
                txtSite.Focus();
                return;
            }

            DataTable dt = new DataTable();
            dt = DatabaseAccess.Retrieve("select * from SiteTable where SiteName = '" + txtSite.Text.Trim() + "' AND SiteID != '" + dgvSiteList.CurrentRow.Cells[0].Value + "'");

            if (dt != null)
            {
                if (dt.Rows.Count > 0)
                {
                    ep.SetError(txtSite, "Already exists!");
                    txtSite.Focus();
                    return;
                }
            }

            string query = string.Format("update SiteTable set SiteName = '{0}' where SiteID = '{1}'", txtSite.Text.Trim(), dgvSiteList.CurrentRow.Cells[0].Value);
            bool result = DatabaseAccess.Update(query);
            if (result)
            {
                MessageBox.Show("Updated successfully");
                DisableControls();
            }
            else
            {
                MessageBox.Show("Error");
            }
        }

        private void editToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (dgvSiteList != null)
            {
                if (dgvSiteList.Rows.Count > 0)
                {
                    if (dgvSiteList.SelectedRows.Count == 1)
                    {
                        txtSite.Text = Convert.ToString(dgvSiteList.CurrentRow.Cells[1].Value);
                        EnableControls();
                    }
                    else
                    {
                        MessageBox.Show("Please select a record!");
                    }
                }
                else
                {
                    MessageBox.Show("List is empty!");
                }
            }
        }

        private void deleteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (dgvSiteList != null)
            {
                if (dgvSiteList.Rows.Count > 0)
                {
                    if (dgvSiteList.SelectedRows.Count == 1)
                    {
                        if (MessageBox.Show("Are you sure you want to delete?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                        {
                            string deletequery = "delete from SiteTable where SiteID = '" + dgvSiteList.CurrentRow.Cells[0].Value + "'";

                            bool result = DatabaseAccess.Delete(deletequery);
                            if (result)
                            {
                                MessageBox.Show("Deleted successfully!");
                                FillGrid("");
                            }
                        }
                    }
                    else
                    {
                        MessageBox.Show("Please select a record!");
                    }
                }
                else
                {
                    MessageBox.Show("List is empty!");
                }
            }
        }
    }
}
