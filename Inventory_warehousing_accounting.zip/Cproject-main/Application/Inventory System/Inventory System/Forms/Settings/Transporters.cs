﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Inventory_System.Forms.Settings
{
    public partial class Transporters : Form
    {
        public Transporters()
        {
            InitializeComponent();
        }

        private void FillGrid(string searchvalue)
        {
            string query = string.Empty;
            DataTable dt = new DataTable();
            if (string.IsNullOrEmpty(searchvalue) && string.IsNullOrWhiteSpace(searchvalue))
            {
                query = "select TransporterID [ID], TransporterName [Transporter Name] from TransporterTable";

            }
            else
            {
                query = "select TransporterID [ID], TransporterName [[Transporter Name] from TransporterTable where TransporterName like '%" + searchvalue + "%'";
            }
            dt = DatabaseAccess.Retrieve(query);
            if (dt != null)
            {
                if (dt.Rows.Count > 0)
                {
                    dgvTransporterList.DataSource = dt;
                    dgvTransporterList.Columns[0].Width = 100;
                    dgvTransporterList.Columns[1].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
                }
                else
                {
                    dgvTransporterList.DataSource = null;
                }
            }
            else
            {
                dgvTransporterList.DataSource = null;
            }
        }

        private void Transporters_Load(object sender, EventArgs e)
        {
            FillGrid("");
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtTransporter.Clear();
        }

        private void EnableControls()
        {
            btnEdit.Enabled = true;
            btnCancel.Enabled = true;
            btnSave.Enabled = false;
            dgvTransporterList.Enabled = false;
            txtSearch.Enabled = false;
        }

        private void DisableControls()
        {
            btnEdit.Enabled = false;
            btnCancel.Enabled = false;
            btnSave.Enabled = true;
            dgvTransporterList.Enabled = true;
            txtSearch.Enabled = true;
            FillGrid("");
            txtTransporter.Clear();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            DisableControls();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            ep.Clear();
            if (txtTransporter.Text.Trim().Length == 0)
            {
                ep.SetError(txtTransporter, "Please enter transporter name");
                txtTransporter.Focus();
                return;
            }

            DataTable dt = new DataTable();
            dt = DatabaseAccess.Retrieve("select * from TransporterTable where TransporterName = '" + txtTransporter.Text.Trim() + "'");

            if (dt != null)
            {
                if (dt.Rows.Count > 0)
                {
                    ep.SetError(txtTransporter, "Already exists!");
                    txtTransporter.Focus();
                    return;
                }
            }

            string query = string.Format("insert into TransporterTable(TransporterName) values('{0}')", txtTransporter.Text.Trim());
            bool result = DatabaseAccess.Insert(query);
            if (result)
            {
                MessageBox.Show("Saved successfully");
                FillGrid("");
            }
            else
            {
                MessageBox.Show("Error");
            }
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            ep.Clear();
            if (txtTransporter.Text.Trim().Length == 0)
            {
                ep.SetError(txtTransporter, "Please enter transporter name");
                txtTransporter.Focus();
                return;
            }

            DataTable dt = new DataTable();
            dt = DatabaseAccess.Retrieve("select * from TransporterTable where TransporterName = '" + txtTransporter.Text.Trim() + "' AND TransporterID != '" + dgvTransporterList.CurrentRow.Cells[0].Value + "'");

            if (dt != null)
            {
                if (dt.Rows.Count > 0)
                {
                    ep.SetError(txtTransporter, "Already exists!");
                    txtTransporter.Focus();
                    return;
                }
            }

            string query = string.Format("update TransporterTable set TransporterName = '{0}' where TransporterID = '{1}'", txtTransporter.Text.Trim(), dgvTransporterList.CurrentRow.Cells[0].Value);
            bool result = DatabaseAccess.Update(query);
            if (result)
            {
                MessageBox.Show("Updated successfully");
                DisableControls();
            }
            else
            {
                MessageBox.Show("Error");
            }
        }

        private void editToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (dgvTransporterList != null)
            {
                if (dgvTransporterList.Rows.Count > 0)
                {
                    if (dgvTransporterList.SelectedRows.Count == 1)
                    {
                        txtTransporter.Text = Convert.ToString(dgvTransporterList.CurrentRow.Cells[1].Value);
                        EnableControls();
                    }
                    else
                    {
                        MessageBox.Show("Please select a record!");
                    }
                }
                else
                {
                    MessageBox.Show("List is empty!");
                }
            }
        }

        private void deleteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (dgvTransporterList != null)
            {
                if (dgvTransporterList.Rows.Count > 0)
                {
                    if (dgvTransporterList.SelectedRows.Count == 1)
                    {
                        if (MessageBox.Show("Are you sure you want to delete?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                        {
                            string deletequery = "delete from TransporterTable where TransporterID = '" + dgvTransporterList.CurrentRow.Cells[0].Value + "'";

                            bool result = DatabaseAccess.Delete(deletequery);
                            if (result)
                            {
                                MessageBox.Show("Deleted successfully!");
                                FillGrid("");
                            }
                        }
                    }
                    else
                    {
                        MessageBox.Show("Please select a record!");
                    }
                }
                else
                {
                    MessageBox.Show("List is empty!");
                }
            }
        }
    }
}
