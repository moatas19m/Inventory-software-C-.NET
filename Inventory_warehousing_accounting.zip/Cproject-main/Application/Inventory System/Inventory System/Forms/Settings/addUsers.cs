﻿using Inventory_System.SourceCode;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Inventory_System.Forms.UserForms
{
    public partial class addUsers : Form
    {
        public addUsers()
        {
            InitializeComponent();
        }

        private void btnAddUserType_Click(object sender, EventArgs e)
        {
            userTypes frm = new userTypes();
            frm.ShowDialog();
            btnRefresh_Click(sender, e);
        }

        private void ClearForm()
        {
            cmbSelectUserType.SelectedIndex = 0;
            txtEmail.Clear();
            txtContactNo.Clear();
            txtFullName.Clear();
            txtPassword.Clear();
            txtUserName.Clear();
            txtConfirmPassword.Clear();
        }

        private void btnRegister_Click(object sender, EventArgs e)
        {
            ep.Clear();
            if (cmbSelectUserType.SelectedIndex == 0)
            {
                ep.SetError(cmbSelectUserType, "Please select user type!");
                cmbSelectUserType.Focus();
                return;
            }

            if (txtFullName.Text.Trim().Length == 0)
            {
                ep.SetError(txtFullName, "Please enter full name");
                txtFullName.Focus();
                return;
             }

            if (txtContactNo.Text.Trim().Length == 0)
            {
                ep.SetError(txtContactNo, "Please enter contact no");
                txtContactNo.Focus();
                return;
            }

            if (txtUserName.Text.Trim().Length == 0)
            {
                ep.SetError(txtUserName, "Please enter user name");
                txtUserName.Focus();
                return;
            }

            if (txtPassword.Text.Trim().Length == 0)
            {
                ep.SetError(txtPassword, "Please enter your password");
                txtPassword.Focus();
                return;
            }

            if (txtConfirmPassword.Text.Trim().Length == 0)
            {
                ep.SetError(txtConfirmPassword, "Please confirm your password");
                txtConfirmPassword.Focus();
                return;
            }

            if (txtPassword.Text.Trim() != txtConfirmPassword.Text.Trim())
            {
                ep.SetError(txtConfirmPassword, "Password does not match");
                txtConfirmPassword.Focus();
                return;
            }

            DataTable dt = DatabaseAccess.Retrieve("select * from UsersTable where UserName = '"+txtUserName+"'"); 
            if (dt != null)
            {
                if (dt.Rows.Count > 0)
                {
                    ep.SetError(txtUserName, "User name already exists!");
                    txtUserName.Focus();
                    return;
                }
            }

            dt = null;
            dt = DatabaseAccess.Retrieve("select * from UsersTable where FullName = '" + txtFullName.Text.Trim() + "' and ContactNo = '"+txtContactNo.Text.Trim()+"'");
            if (dt != null)
            {
                if (dt.Rows.Count > 0)
                {
                    ep.SetError(txtFullName, "User already registered!");
                    txtFullName.Focus();
                    return;
                }
            }

            string insertquery = string.Format("insert into UsersTable(UserType_ID, FullName, Email, ContactNo, UserName, Password) values ('{0}', '{1}', '{2}', '{3}', '{4}', '{5}')", cmbSelectUserType.SelectedValue, txtFullName.Text.Trim(), txtEmail.Text.Trim(), txtContactNo.Text.Trim(), txtUserName.Text.Trim(), txtPassword.Text.Trim()); 

            bool result = DatabaseAccess.Insert(insertquery);
            if (result)
            {
                MessageBox.Show("User registered successfully");
                this.Close();
            }else
            {
                MessageBox.Show("Error");  
            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            ClearForm();
        }

        private void addUsers_Load(object sender, EventArgs e)
        {
            ComboHelper.FillUserTypes(cmbSelectUserType);
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            ComboHelper.FillUserTypes(cmbSelectUserType);
        }
    }
}
