﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Inventory_System.Forms.StockForms
{
    public partial class Categories : Form
    {
        public Categories()
        {
            InitializeComponent();
        }

        private void FillGrid(string searchvalue)
        {
            string query = string.Empty;
            DataTable dt = new DataTable();
            if (string.IsNullOrEmpty(searchvalue) && string.IsNullOrWhiteSpace(searchvalue))
            {
                query = "select CategoryID [ID], CategoryName [Category] from CategoryTable";

            }
            else
            {
                query = "select CategoryID [ID], CategoryName [Category] from CategoryTable where CategoryName like '%" + searchvalue + "%'";
            }
            dt = DatabaseAccess.Retrieve(query);
            if (dt != null)
            {
                if (dt.Rows.Count > 0)
                {
                    dgvCategoryList.DataSource = dt;
                    dgvCategoryList.Columns[0].Width = 100;
                    dgvCategoryList.Columns[1].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
                }
                else
                {
                    dgvCategoryList.DataSource = null;
                }
            }
            else
            {
                dgvCategoryList.DataSource = null;
            }
        }

        private void Categories_Load(object sender, EventArgs e)
        {
            FillGrid("");
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtCategory.Clear();
        }

        private void EnableControls()
        {
            btnEdit.Enabled = true;
            btnCancel.Enabled = true;
            btnSave.Enabled = false;
            dgvCategoryList.Enabled = false;
            txtSearch.Enabled = false;
        }

        private void DisableControls()
        {
            btnEdit.Enabled = false;
            btnCancel.Enabled = false;
            btnSave.Enabled = true;
            dgvCategoryList.Enabled = true;
            txtSearch.Enabled = true;
            FillGrid("");
            txtCategory.Clear();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            DisableControls();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            ep.Clear();
            if (txtCategory.Text.Trim().Length == 0)
            {
                ep.SetError(txtCategory, "Please enter category name");
                txtCategory.Focus();
                return;
            }

            DataTable dt = new DataTable();
            dt = DatabaseAccess.Retrieve("select * from CategoryTable where CategoryName = '"+txtCategory.Text.Trim()+"'");

            if (dt != null)
            {
                if (dt.Rows.Count > 0)
                {
                    ep.SetError(txtCategory, "Already exists!");
                    txtCategory.Focus();
                    return;
                }
            }

            string query = string.Format("insert into CategoryTable(CategoryName) values('{0}')", txtCategory.Text.Trim());
            bool result = DatabaseAccess.Insert(query);
            if (result)
            {
                MessageBox.Show("Saved successfully");
                FillGrid("");
            }
            else
            {
                MessageBox.Show("Error");
            }
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            ep.Clear();
            if (txtCategory.Text.Trim().Length == 0)
            {
                ep.SetError(txtCategory, "Please enter category name");
                txtCategory.Focus();
                return;
            }

            DataTable dt = new DataTable();
            dt = DatabaseAccess.Retrieve("select * from CategoryTable where CategoryName = '" + txtCategory.Text.Trim() + "' AND CategoryID != '"+dgvCategoryList.CurrentRow.Cells[0].Value+"'");

            if (dt != null)
            {
                if (dt.Rows.Count > 0)
                {
                    ep.SetError(txtCategory, "Already exists!");
                    txtCategory.Focus();
                    return;
                }
            }

            string query = string.Format("update CategoryTable set CategoryName = '{0}' where CategoryID = '{1}'", txtCategory.Text.Trim(), dgvCategoryList.CurrentRow.Cells[0].Value);
            bool result = DatabaseAccess.Update(query);
            if (result)
            {
                MessageBox.Show("Updated successfully");
                DisableControls();
            }
            else
            {
                MessageBox.Show("Error");
            }
        }

        private void editToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (dgvCategoryList != null)
            {
                if (dgvCategoryList.Rows.Count > 0)
                {
                    if (dgvCategoryList.SelectedRows.Count == 1)
                    {
                        txtCategory.Text = Convert.ToString(dgvCategoryList.CurrentRow.Cells[1].Value);
                        EnableControls();
                    }
                    else
                    {
                        MessageBox.Show("Please select a record!");
                    }
                }
                else
                {
                    MessageBox.Show("List is empty!");
                }
            }
        }

        private void deleteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (dgvCategoryList != null)
            {
                if (dgvCategoryList.Rows.Count > 0)
                {
                    if (dgvCategoryList.SelectedRows.Count == 1)
                    {
                        if (MessageBox.Show("Are you sure you want to delete?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                        {
                            string deletequery = "delete from CategoryTable where CategoryID = '"+dgvCategoryList.CurrentRow.Cells[0].Value+"'";

                            bool result = DatabaseAccess.Delete(deletequery);
                            if (result)
                            {
                                MessageBox.Show("Deleted successfully!");
                                FillGrid("");
                            }
                        }
                    }
                    else
                    {
                        MessageBox.Show("Please select a record!");
                    }
                }
                else
                {
                    MessageBox.Show("List is empty!");
                }
            }
        }
    }
}
