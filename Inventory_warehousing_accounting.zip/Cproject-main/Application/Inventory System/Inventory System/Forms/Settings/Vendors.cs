﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Inventory_System.Forms.StockForms
{
    public partial class Vendors : Form
    {
        public Vendors()
        {
            InitializeComponent();
        }

        private void FillGrid(string searchvalue)
        {
            string query = string.Empty;
            DataTable dt = new DataTable();
            if (string.IsNullOrEmpty(searchvalue) && string.IsNullOrWhiteSpace(searchvalue))
            {
                query = "select VendorID [ID], VendorName [Vendor Name] from VendorTable";

            }
            else
            {
                query = "select VendorID [ID], VendorName [[Vendor Name] from VendorTable where VendorName like '%" + searchvalue + "%'";
            }
            dt = DatabaseAccess.Retrieve(query);
            if (dt != null)
            {
                if (dt.Rows.Count > 0)
                {
                    dgvVendorList.DataSource = dt;
                    dgvVendorList.Columns[0].Width = 100;
                    dgvVendorList.Columns[1].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
                }
                else
                {
                    dgvVendorList.DataSource = null;
                }
            }
            else
            {
                dgvVendorList.DataSource = null;
            }
        }

        private void Vendors_Load(object sender, EventArgs e)
        {
            FillGrid("");
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtVendor.Clear();
        }

        private void EnableControls()
        {
            btnEdit.Enabled = true;
            btnCancel.Enabled = true;
            btnSave.Enabled = false;
            dgvVendorList.Enabled = false;
            txtSearch.Enabled = false;
        }

        private void DisableControls()
        {
            btnEdit.Enabled = false;
            btnCancel.Enabled = false;
            btnSave.Enabled = true;
            dgvVendorList.Enabled = true;
            txtSearch.Enabled = true;
            FillGrid("");
            txtVendor.Clear();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            DisableControls();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            ep.Clear();
            if (txtVendor.Text.Trim().Length == 0)
            {
                ep.SetError(txtVendor, "Please enter vendor name");
                txtVendor.Focus();
                return;
            }

            DataTable dt = new DataTable();
            dt = DatabaseAccess.Retrieve("select * from VendorTable where VendorName = '" + txtVendor.Text.Trim() + "'");

            if (dt != null)
            {
                if (dt.Rows.Count > 0)
                {
                    ep.SetError(txtVendor, "Already exists!");
                    txtVendor.Focus();
                    return;
                }
            }

            string query = string.Format("insert into VendorTable(VendorName) values('{0}')", txtVendor.Text.Trim());
            bool result = DatabaseAccess.Insert(query);
            if (result)
            {
                MessageBox.Show("Saved successfully");
                FillGrid("");
            }
            else
            {
                MessageBox.Show("Error");
            }
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            ep.Clear();
            if (txtVendor.Text.Trim().Length == 0)
            {
                ep.SetError(txtVendor, "Please enter vendor name");
                txtVendor.Focus();
                return;
            }

            DataTable dt = new DataTable();
            dt = DatabaseAccess.Retrieve("select * from VendorTable where VendorName = '" + txtVendor.Text.Trim() + "' AND VendorID != '" + dgvVendorList.CurrentRow.Cells[0].Value + "'");

            if (dt != null)
            {
                if (dt.Rows.Count > 0)
                {
                    ep.SetError(txtVendor, "Already exists!");
                    txtVendor.Focus();
                    return;
                }
            }

            string query = string.Format("update VendorTable set VendorName = '{0}' where VendorID = '{1}'", txtVendor.Text.Trim(), dgvVendorList.CurrentRow.Cells[0].Value);
            bool result = DatabaseAccess.Update(query);
            if (result)
            {
                MessageBox.Show("Updated successfully");
                DisableControls();
            }
            else
            {
                MessageBox.Show("Error");
            }
        }

        private void editToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (dgvVendorList != null)
            {
                if (dgvVendorList.Rows.Count > 0)
                {
                    if (dgvVendorList.SelectedRows.Count == 1)
                    {
                        txtVendor.Text = Convert.ToString(dgvVendorList.CurrentRow.Cells[1].Value);
                        EnableControls();
                    }
                    else
                    {
                        MessageBox.Show("Please select a record!");
                    }
                }
                else
                {
                    MessageBox.Show("List is empty!");
                }
            }
        }

        private void deleteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (dgvVendorList != null)
            {
                if (dgvVendorList.Rows.Count > 0)
                {
                    if (dgvVendorList.SelectedRows.Count == 1)
                    {
                        if (MessageBox.Show("Are you sure you want to delete?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                        {
                            string deletequery = "delete from VendorTable where VendorID = '" + dgvVendorList.CurrentRow.Cells[0].Value + "'";

                            bool result = DatabaseAccess.Delete(deletequery);
                            if (result)
                            {
                                MessageBox.Show("Deleted successfully!");
                                FillGrid("");
                            }
                        }
                    }
                    else
                    {
                        MessageBox.Show("Please select a record!");
                    }
                }
                else
                {
                    MessageBox.Show("List is empty!");
                }
            }
        }
    }
}
